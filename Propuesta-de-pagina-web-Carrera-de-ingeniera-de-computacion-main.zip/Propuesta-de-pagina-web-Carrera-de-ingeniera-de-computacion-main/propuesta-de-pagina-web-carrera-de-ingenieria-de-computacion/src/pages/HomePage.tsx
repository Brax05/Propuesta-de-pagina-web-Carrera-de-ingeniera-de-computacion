import React from 'react';
//import { Container, Row, Col, Button, Card, Image } from 'react-bootstrap';
//import { Link } from 'react-router-dom';
import NavbarPage from '../components/Navbarpage';

const HomePage: React.FC = () => {
  return (
    <div>
      <NavbarPage />  {/* Aquí solo se muestra el Navbar */}
    </div>
  );
};

export default HomePage;
